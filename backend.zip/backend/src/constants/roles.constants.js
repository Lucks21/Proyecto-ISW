const ROLES = ["user", "encargado", "admin", "alumno"];

export default ROLES;
